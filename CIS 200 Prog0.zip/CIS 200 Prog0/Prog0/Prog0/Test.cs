﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Grading ID C2652, Program 0, 9/11/17, CIS200-01
//test input class
public class Test
{
    static void Main()
    {
        //test address objects
        var a1 = new Address("Joseph", "Address 1", "Address 2", "City", "State", 40208);
        var a2 = new Address("David", "Address 1", "City", "State", 00008);
        var a3 = new Address("Sheri", "Address 1", "Address 2", "City", "State", 40214);
        var a4 = new Address("Chris", "Address 1", "City", "State", 40214);

        //test letter objects
        var le1 = new Letter(a1,a2,4);
        var le2 = new Letter(a3, a4, 3);
        var le3 = new Letter(a1, a3, 2);

        //declare and initialize list of letter objects
        var letters = new List<Parcel> {le1, le2, le3};

        //loop through list
        foreach(var let in letters)
        {
            //print each object to console
            Console.WriteLine($"{let}");
        }

        //display console
        Console.Read();
    }
}
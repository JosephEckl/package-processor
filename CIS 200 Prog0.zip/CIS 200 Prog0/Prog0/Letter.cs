﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Grading ID C2652, Program 0, 9/11/17, CIS200-01
//letter building class

//inherit from parcel class
public class Letter : Parcel
{
    //backing field
    private decimal _fixedCost;

    //precondition: properties must have values
    //postcondition: object now has values passed from properties
    //constructor to form letter
    public Letter(Address originAddress, Address destinationAddress, decimal fixedCost) : base (originAddress, destinationAddress)
    {
        //assign property to constructor
        FixedCost = fixedCost;
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    //property for cost field
    private decimal FixedCost
    {
        get
        {
            return _fixedCost;
        }
        set
        {
            _fixedCost = value;
        }
    }

    //specify cost method
    public override decimal CalcCost()
    {
        return FixedCost;
    }

    //override tostring to format
    public override string ToString()
    {
        return $"{OriginAddress}{DestinationAddress}{FixedCost:C}\n";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Grading ID C2652, Program 0, 9/11/17, CIS200-01
//address building class
public class Address
{
    //backing fields
    private String _name;
    private String _address1;
    private String _address2;
    private String _city;
    private String _state;
    private int _zip;

    //precondition: properties must have values
    //postcondition: object now has values passed from properties
    //constructor 1 (2 addresses)
    public Address (String name, String address1, String address2, String city, String state, int zip)
    {
        //assign property to constructor
        Name = name;
        Address1 = address1;
        Address2 = address2;
        City = city;
        State = state;
        Zip = zip;
    }

    //precondition: properties must have values
    //postcondition: object now has values passed from properties
    //overloaded constructor 2 (1 address)
    public Address (String name, String address1, String city, String state, int zip)
    {
        //assign property to constructor
        Name = name;
        Address1 = address1;
        Address2 = "";
        City = city;
        State = state;
        Zip = zip;
    }

    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    //properties for each field
    public String Name
    {
        get
        {
            return _name;
        }
        set
        {
            _name = value;
        }
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public String Address1
    {
        get
        {
            return _address1;
        }
        set
        {
            _address1 = value;
        }
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public String Address2
    {
        get
        {
            return _address2;
        }
        set
        {
            _address2 = value;
        }
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public String City
    {
        get
        {
            return _city;
        }
        set
        {
            _city = value;
        }
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public String State
    {
        get
        {
            return _state;
        }
        set
        {
            _state = value;
        }
    }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public int Zip
    {
        get
        {
            return _zip;
        }
        set
        {
            _zip = value;
        }
    }

    //override tostring to custom format
    public override string ToString()
    {
        // check to include address
        //if 2nd constructor was used, leave out blank address 2 in format
        if (Address2 == "")
        {
            return $"{Name}\n{Address1}\n{City} {State} {Zip:D5}\n";
        }
        //otherwise, return full address formatted
        else
        {
            return $"{Name}\n{Address1}\n{Address2}\n{City} {State} {Zip:D5}\n";
        }
        
    }
}
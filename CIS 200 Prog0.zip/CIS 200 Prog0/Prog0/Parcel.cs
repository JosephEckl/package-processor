﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Grading ID C2652, Program 0, 9/11/17, CIS200-01
//abstract parcel class for inheritance
public abstract class Parcel
    {
        //backing fields to recieve addresses
        public Address _originAddress;
        public Address _destinationAddress;

    //precondition: properties must have values
    //postcondition: object now has values passed from properties
    //constructor using generated addresses
    public Parcel(Address originAddress, Address destinationAddress)
        {
            //assign properties to constuctor
            OriginAddress = originAddress;
            DestinationAddress = destinationAddress;
        }

    //properties for both address types
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public Address OriginAddress
        {
            get
            {
                return _originAddress;
            }
            set
            {
                _originAddress = value;
            }
        }
    //precondition: property must recieve proper type
    //postcondition: property now contains a value
    public Address DestinationAddress
        {
            get
            {
                return _destinationAddress;
            }
            set
            {
                _destinationAddress = value;
            }
        }

        //abstract method, will be specified in inherited class
        public abstract decimal CalcCost();
        
        //override tostring to format values
        public override string ToString()
        {
            return $"{OriginAddress}\n{DestinationAddress}";
        }
    }
